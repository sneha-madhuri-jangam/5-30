import React from 'react'

function Pdfextract() {
  return (
    <div>
      <h1>pdf</h1>
    </div>
  )
}

export default Pdfextract
