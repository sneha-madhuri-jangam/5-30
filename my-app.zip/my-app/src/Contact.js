import React, { useState } from "react";
import axios from "axios";
import "./App.css"; // Optional: For styling purposes

// Ensure you have your API key set up in a secure manner.
// const apiKey = "AIzaSyDqzPGIfh_3MGkZl6xKvKxZNMmP_gVkRrk";
const apiKey="AIzaSyATAQfRV-uE2aQE5TpAzuYNW8o6G_HmJEo";

function Contact() {
  const [query, setQuery] = useState("");
  const [videos, setVideos] = useState([]);

  const youtubeSearch = async (searchQuery) => {
    const searchUrl = "https://www.googleapis.com/youtube/v3/search";
    const params = {
      part: "snippet",
      q: searchQuery,
      type: "video",
      key: apiKey,
      maxResults: 5,
    };

    try {
      const response = await axios.get(searchUrl, { params });
      if (response.status === 200) {
        const results = response.data.items.map((item) => ({
          title: item.snippet.title,
          videoId: item.id.videoId,
          thumbnailUrl: item.snippet.thumbnails.default.url,
        }));
        setVideos(results);
      } else {
        console.error(
          `Failed to retrieve results. HTTP Status code: ${response.status}`
        );
      }
    } catch (error) {
      console.error(`Error occurred while fetching data: ${error.message}`);
    }
  };

  const handleSearch = () => {
    youtubeSearch(query);
  };

  return (
    <div className="App">
      <h1>YouTube Video Search</h1>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Enter search query"
      />
      <button onClick={handleSearch}>Search</button>
      <div>
        {videos.map((video) => (
          <a
            key={video.videoId}
            href={`https://www.youtube.com/watch?v=${video.videoId}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <div>
              <h3>{video.title}</h3>
              <img src={video.thumbnailUrl} alt={video.title} />
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
export default Contact;