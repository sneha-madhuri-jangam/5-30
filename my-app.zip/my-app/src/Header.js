import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { GlobalState } from './App';
import { useNavigate } from 'react-router-dom';
// import './index.css'; 

const Header = () => {
    const {login,username}=useContext(GlobalState)
    const navigate = useNavigate();
    const handleLogout = () => {
        navigate('/'); // Redirect to home page
      };
  return (
    <header className="bg-gray-800 text-white p-4">
      <nav className="flex items-center justify-between">
        <div className="flex space-x-4">
          <Link to={login?"/":"/login"} className="text-white">Home</Link>
          <Link to={login?"/view":"/login"}>View</Link>
          <Link to="/About" className="text-white">About</Link>
          <Link to="/Contact" className="text-white">Contact</Link>
          {!login ? (
            <li><Link to="/login" className="text-white">Login</Link></li>
          ) : (
            <li><button onClick={handleLogout}>Logout</button></li>
          )}

          
        

          
          {/* <h1>{username}</h1> */}
        </div>
      </nav>
    </header>
  );
};
export default Header;