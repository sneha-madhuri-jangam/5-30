import React from 'react';
// import './index.css'; 
const Summarization = () => {
  return (
    <div className="container mx-auto mt-4">
      <h1 >quiz</h1>
      <p></p>
    </div>
  );
};

export default Summarization;