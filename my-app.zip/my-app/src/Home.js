import React from 'react';
// import './index.css'; 
import Image from './homebg.jpeg';


const Home = () => {
  return (
    <div className="container mx-auto mt-4">
      <h1 className="text-4xl font-bold text-center h-14 bg-gradient-to-r rounded-full from-purple-500 to-gray-500">WELCOME TO LEARN-EASY</h1>
      <div class="flex justify-center items-center">
        
      {/* <img src={Image} style={{}}/> */}
     </div>
    </div>
  );
};
export default Home;