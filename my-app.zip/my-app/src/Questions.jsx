import React from 'react'

function Questions() {
  return (
    <div>
      <h1>ques</h1>
    </div>
  )
}

export default Questions
