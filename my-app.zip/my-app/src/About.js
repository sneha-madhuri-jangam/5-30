import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
return (
<nav>
<ul>
<li><Link to="/"  text-white>Home</Link></li>
<li><Link to="/quiz">Quiz</Link></li>
<li><Link to="/summarization">Summarization</Link></li>
<li><Link to="/questions">Questions</Link></li>
<li><Link to="/pdfextract">PDF Extraction</Link></li>
</ul>
</nav>
);
};

export default Navbar;