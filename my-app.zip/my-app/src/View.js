import {Button} from "@nextui-org/react";
import {Input} from "@nextui-org/react";
// import { useState } from "react";
import React, { useState } from 'react';
import axios from 'axios';
import DataDisplay from './DataDisplay'; 
import DataDisplay1 from "./DataDisplay1";
// Import the new DataDisplay component


// import {Input} from "@nextui-org/input";

// function View()


// {
    
    
//     return(
//        <>
//  <div className="flex justify-center items-center h-screen bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500">
//   <div className="w- h-1/4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg p-8">
//     <Input
//       isClearable
//       type="text"
//       label="enter your url"
//       variant="bordered"
//       placeholder="Paste link here"
//       defaultValue=""
//       onClear={() => console.log("input cleared")}
//       className="w-full p-4 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
//     />
//     <Button className="decoration-gray-700 items-center"
//     onClick={fetchData}
//     >
//       Button
//     </Button>

// <Newcomp>
//     <Input
//       isClearable
//       type="text"
//       label="the prompt generated"
//     //   variant="bordered"
//     //   placeholder=""
//     //   defaultValue=""
//       onClear={() => console.log("input cleared")}
//       className="w-full p-4 text-lg  border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
//     />

// </Newcomp>



 function View() {
  const [description, setDescription] = useState('This is a simple Tailwind CSS textarea.');
  const [data, setData] = useState(null);
  const [data1, setData1] = useState(null);
//   const [image, setimage] = useState(null);
  // Store the fetched data
   // Store the fetched data
  const [error, setError] = useState('');

  const fetchData = async () => {
    setError('');
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts/1');
      setData(response.data);
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  const fetchDataque = async () => {
    setError('');
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts/1');
      setData1(response.data);
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <Input
      isClearable
      type="text"
      label="enter your url"
      variant="bordered"
      placeholder="Paste link here"
      defaultValue=""
      onClear={() => console.log("input cleared")}
      className="w-full p-4 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
      value={description}
       onChange={(e) => setDescription(e.target.value)}
      />

      <button
        onClick={fetchData}
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        summarize
      </button>



      <button
        onClick={fetchDataque}
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
      >
        Generate questions
      </button>


      {error && <p className="mt-4 text-red-500">{error}</p>}
      {data && <DataDisplay data={data} />} {/* Display the fetched data */}

      {data1 && <DataDisplay1 data={data1}/>}

      {}


    </div>
  );
}


export default View;